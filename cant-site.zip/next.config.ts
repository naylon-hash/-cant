import type { NextConfig } from 'next';
const nextConfig: NextConfig = {};
export default nextConfig;
